# Sujet Examen 2 - Application de Consultation Littéraire SwiftUI

---

## 👨‍💻 Informations de Soumission

Ce document est le "readme.md" requis pour la soumission du projet.

| Catégorie | Valeur |
| :--- | :--- |
| **Noms & Prénoms des Auteurs** | MUHIRWA GABO Oreste, GUETH Baptiste |
| **Version d'Xcode Utilisée** | Xcode 17.0 (ou la version la plus récente compatible avec Swift 5.x) |
| **Langage** | Swift 5 (SwiftUI) |

---

## 🏗 Description de l'Architecture : MVVM (Model-View-ViewModel)

L'application est développée selon le pattern **MVVM** (Model-View-ViewModel), qui est la méthode architecturale privilégiée pour les projets **SwiftUI**. Cette approche garantit une excellente **séparation des préoccupations (Separation of Concerns)** entre la logique métier, la gestion de l'état et l'interface utilisateur.

### 1. Modèles (Models)

Le dossier `Models` contient les structures de données de base de l'application.

| Fichier | Rôle | Description |
| :--- | :--- | :--- |
| `Book.swift` | **Data Structure** | Définit la structure principale d'un livre (titre, auteur, URL de couverture, etc.). Elle est conforme au protocole `Codable` pour la désérialisation depuis l'API. |

### 2. Services

Le dossier `Services` isole la logique de communication externe.

| Fichier | Rôle | Description |
| :--- | :--- | :--- |
| `BookService.swift` | **Networking/Data Layer** | Responsable de l'accès à l'API Gutendex. Il gère la construction des requêtes URL et le décodage JSON en structures `Book`. Il utilise la concurrence moderne de Swift (`async/await`). |

### 3. ViewModels

Le dossier `ViewModels` gère l'état et la logique de présentation, exposant les données aux vues via des propriétés **`@Published`**.

| Fichier | Rôle | Description |
| :--- | :--- | :--- |
| `BookViewModel.swift` | **Main Catalog Logic** | Gère le catalogue principal. Responsabilités : chargement initial des données, gestion des filtres par étagères (`bookshelves`), tri, et gestion de l'état de l'interface (ex. : `isLoading`). Il est marqué avec **`@MainActor`** pour assurer la sécurité thread. |
| `FavoritesViewModel.swift` | **Persistence/State Logic** | Gère l'état des livres marqués comme favoris. Il utilise probablement `UserDefaults` ou un mécanisme de persistance simple pour sauvegarder les favoris entre les sessions. |

### 4. Vues (Views)

Le dossier `Views` contient tous les éléments de l'interface utilisateur qui réagissent aux ViewModels.

| Fichier | Rôle | Fonctionnalité Clé |
| :--- | :--- | :--- |
| `AllBooksView.swift` | **Tab View** | Affiche le catalogue principal. Permet la recherche et l'accès au filtrage. |
| `BookRowView.swift` | **Component** | Composant réutilisable pour afficher un livre dans une liste (ligne). Intègre le `matchedGeometryEffect` pour l'animation. |
| `BookDetailView.swift` | **Detail View** | Affiche les informations complètes d'un livre. Point de destination de l'animation **Matched Geometry Effect**. |
| `FavoritesView.swift` | **Tab View** | Affiche la liste des livres favoris avec possibilité de suppression. |
| `FilterBookshelvesView.swift`| **Modal View** | Interface pour sélectionner les catégories (`bookshelves`) pour filtrer la liste des livres. |

### Flux de Données (MVVM)

Le flux de données est **unidirectionnel** et piloté par les événements :

1.  **Views** observent les ViewModels.
2.  Les **ViewModels** appellent les **Services** pour obtenir des données.
3.  Les **Services** retournent des **Models** aux ViewModels.
4.  Les ViewModels mettent à jour leurs propriétés **`@Published`**.
5.  Les **Views** se mettent à jour automatiquement.
